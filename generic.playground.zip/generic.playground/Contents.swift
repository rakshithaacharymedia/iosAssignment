//: Playground - noun: a place where people can play

import UIKit
import PlaygroundSupport

//use generic to display the array
func display<T>(a:[T])
{
    print("items are",a)
}

display(a: ["A","b","c"])
display(a: [1,2,3,4])
display(a: [0.3,0.5])

//use generics to add 2 numbers

func add<t:Numeric>(a:[t])->t{
    return a.reduce(1){$0*$1}             //using reduce
}
print("the sum of integer is  ",add(a: [1,2,3,4]))
print("The sum of float no is",add(a: [1.2,2.3,5.6]))


//use genericsto compare numbers and strings
func compare<t:Equatable>(a:t,b:t)
{
    if a == b
    {
        print(a,"and ",b," is same")
    }
    else
    {
    print(a,"and",b," not same")
}
}
compare(a: "hello", b: "world")
compare(a: 1, b: 1)
compare(a: "hello", b:"hello")

///using generics with 2 different type
func sameType<T,E>(one: T,  two: E) -> Void {
    print("im infunction 1")
    if(type(of: one) == type(of: two)) {
        print("they are same")
    }
    else {
        print("not same type")
    }
}
func sameType<T>(one: T,  two: T) -> Void {
    
    print("im in func 2")
    if(type(of: one) == type(of: two)) {
        print("they are same")
    }
    else {
        print("not same type")
    }
}
sameType(one: "hello", two: 5)   //calls 1st function since
sameType(one: "hello", two: "world")         //calls 2nd fuction since both parameters are of same type


//use comparable to sort the elements of array
func  sortingarray<t:Comparable>(a:[t])
{
    if a.count != 0{
        print(a.sorted(by:>))
    }else{
        print("array is empty")
    }
}
sortingarray(a: [2,4,1,55,6,9,2,99])
sortingarray(a: ["a","c","dd","qq","aaa"])



//generic with structure

struct stocklevel<t:Numeric & Equatable & Comparable>{
  var price:t
  func display(){
        print("price is",price,"its type is ",type(of: price))
    }
    func add(quantity:t)->stocklevel
    {
        return stocklevel(price: self.price*quantity)
    }
    //comparing 2 structure objects
    static func == (lhs: stocklevel, rhs: stocklevel) -> Bool {
        return lhs.price == rhs.price
    }
    static func >= (lhs: stocklevel, rhs: stocklevel) -> Bool {
        return lhs.price >= rhs.price
    }
    static func compareobject(stock11:stocklevel,stock22:stocklevel)
    {
        if stock11 == stock22
        {
            print("THE 2 OBJECTS ARE SAME")
        }
        else
        {
            print("the 2 objects are different")
        }
    }
}

var stock1=stocklevel(price: 550)
var stock2=stocklevel(price:5055)
stock1.display()
stock2.display()
print("Is two objects are similar",stock1==stock2)
print("Is stock1 greater than stock2 objects ",stock1>=stock2)
let newstock=stock1.add(quantity: 55)
print(newstock.price)
let newstock1=stock2.add(quantity: 89)   //should be double ..since type of price is double
stocklevel.compareobject(stock11: stock1, stock22: stock2)

//generic protocol  + class

protocol genericprotocol{
    associatedtype mytype                  //type of generic
    var anyproperty:mytype{get set}
}
extension genericprotocol where mytype==String{
   func anyfunction(){
        print("im in anyfunction",anyproperty)
    }
}
class someclass:genericprotocol{
  //  var anyproperty:String="abc"     //defining type implicitly
  //  var anyproperty="abc"              //compiler understands
   typealias mytype = String
   var anyproperty: mytype="abc"            //defining explicitlyusing typealias

}
someclass().anyfunction()
