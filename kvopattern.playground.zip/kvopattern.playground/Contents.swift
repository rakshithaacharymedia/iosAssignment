//: Playground - noun: a place where people can play

import UIKit


class account:NSObject{
    var  accountNumber:Int=314568215
    @objc dynamic var balance:Int=0
    func display() {
        print("Person with account no ",accountNumber,"has a balance of ",balance)
    }
    func change(amount:Int)
    {
        balance+=amount
        
    }
}

class person:NSObject{
    var name:String="rakshitha"
    @objc var observed:account
    var observer:NSKeyValueObservation?
    func displayperson(){
        print("The name of the person is",name)
    }
    init(object:account)
    {
        observed=object
        super.init()
        
        observer=observe(\.observed.balance,options:[.old,.new]){ object,change in print("The balance changed from ",change.oldValue!," to ",change.newValue!)
        }
        
    }
}

let a=account.init()
let p=person(object:a)
p.displayperson()
a.change(amount: 500)
a.change(amount: 1000)

