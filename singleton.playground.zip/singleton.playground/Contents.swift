//: Playground - noun: a place where people can play

import UIKit

import PlaygroundSupport


class Singleton{
    static let shared = Singleton()
   // static let shared2=Singleton()
    static var age:Int=8
    var username: String?
    private init()
    {
      print("Im in private in initializer")

    }
    func displayusername(username:String)
    {
        print("The username is ",username)
    }
    static func displayClassdetail()
    {
        print("Im a singleton class")
        print("age is ",age)
    }
}

let a = Singleton.shared
let b = Singleton.shared
a === b
print("Calling initializer")
var name=Singleton.shared.username
name="rakshitha"
Singleton.shared.displayusername(username:name!) //calls instance method
Singleton.age=54
Singleton.displayClassdetail()                     //calls static method

//Singleton.shared === Singleton.shared2
//var names=Singleton.shared2.username
//
//


